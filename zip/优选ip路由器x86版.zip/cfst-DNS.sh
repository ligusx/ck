#!/usr/bin/env bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
# --------------------------------------------------------------
#	项目: 基于CloudflareSpeedTest的 N1 自动更新 IP
#	版本: 1.2.0
#	作者: 鸿煊
#	项目: https://github.com/Lbingyi/CloudflareSpeedTest
#	使用说明：加在openwrt上系统--计划任务里添加定时运行，如0 9 * * * bash /root/CloudflareST/cfst-DNS.sh
#	*解释：9点0分运行一次。
#	路由上的爬墙软件节点IP全部换成路由IP，如192.168.1.1:8443，端口全部8443
#	使用前请更换自己的推送token 注册地址下下方
# --------------------------------------------------------------

localport=8443
remoteport=443
pushplus=自己的token
ServerChan=自己的token
ServerChanTurbo=自己的token
Telegrambot=自己的token
cd /root/CloudflareST
echo -e "开始测速..."
NOWIP=$(head -1 nowip.txt)
	
# 这里可以自己添加、修改 CloudflareST 的运行参数

./CloudflareST

BESTIP=$(sed -n "2,1p" result.csv | awk -F, '{print $1}')
if [[ -z "${BESTIP}" ]]; then
	echo "CloudflareST 测速结果 IP 数量为 0，跳过下面步骤..."
	exit 0
fi
echo ${BESTIP} > nowip.txt
echo -e "\n旧 IP 为 ${NOWIP}\n新 IP 为 ${BESTIP}\n"

echo -e "开始替换..."
iptables -t nat -D OUTPUT $(iptables -t nat -nL OUTPUT --line-number | grep ${localport} | awk '{print $1}')
iptables -t nat -A OUTPUT -p tcp --dport ${localport} -j DNAT --to-destination ${BESTIP}:${remoteport}
rm -rf result.csv
echo -e "完成..."

curl -s -o /dev/null --data "token=${pushplus}&title=${BESTIP}更新成功！&content=优选IP ${BESTIP}<br>平均延迟 ${Average} ms<br>下载速度 ${speed} MB/s <br>丢包率 ${Packet} %<br>&template=html" http://www.pushplus.plus/send #微信推送最新查找的IP-pushplus推送加

curl -s -o /dev/null --data "text=${BESTIP}更新成功！&desp=$(date +'%Y-%m-%d %H:%M:%S') %0D%0A%0D%0A---%0D%0A%0D%0A * 优选IP ${BESTIP} %0D%0A * 平均延迟 ${Average} ms %0D%0A * 下载速度 ${speed} MB/s %0D%0A * 丢包率 ${Packet} % %0D%0A" https://sc.ftqq.com/${ServerChan}.send #微信推送最新查找的IP-Server酱
	
#	curl -s -o /dev/null --data "title=${BESTIP}更新成功！&desp=$(date +'%Y-%m-%d %H:%M:%S') %0D%0A%0D%0A---%0D%0A%0D%0A * 优选IP ${BESTIP} %0D%0A * 平均延迟 ${Average} ms %0D%0A * 下载速度 ${speed} MB/s %0D%0A * 丢包率 ${Packet} % %0D%0A"  https://sctapi.ftqq.com/${ServerChanTurbo}.send #微信推送最新查找的IP-Server酱·Turbo版
	
#	curl -s -o /dev/null --data "&text=*${BESTIP}更新成功！* %0D%0A$(date +'%Y\-%m\-%d %H:%M:%S')%0D%0A----------------------------------%0D%0A·优选IP ${BESTIP} %0D%0A·平均延迟 ${Average} ms%0D%0A·下载速度 ${speed} MB/s %0D%0A·丢包率 ${Packet} % %0D%0A----------------------------------&parse_mode=Markdown" https://pushbot.pupilcc.com/sendMessage/${Telegrambot} #Telegram推送最新查找的IP- @notification_me_bot
