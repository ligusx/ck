<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>文件下载</title>
</head>
<body>
    <h1>文件列表</h1>
    <ul>
    <?php
    // 设置当前目录
    $dir = ".";
    // 打开目录
    if ($handle = opendir($dir)) {
        // 遍历目录
        while (false !== ($entry = readdir($handle))) {
            // 过滤掉点和..以及隐藏文件
            if ($entry != "." &&$entry != ".." && substr($entry, 0, 1) != '.' &&$entry != "index.php") {
            // 输出文件名和下载链接
                echo "<li><a href='$entry'>$entry</a></li>";
            }
        }
        closedir($handle);
    }
    ?>
    </ul>
</body>
</html>
